#!/usr/bin/env python3

import brain_games.games.prime_game


def main():
    brain_games.games.prime_game.main()


if __name__ == "__main__":
    main()
