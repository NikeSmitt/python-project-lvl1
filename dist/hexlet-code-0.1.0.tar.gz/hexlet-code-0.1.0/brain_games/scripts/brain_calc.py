import brain_games.games.calc_game


def main():
    print("Welcome to the Brain Games!")
    brain_games.games.calc_game.main()


if __name__ == "__main__":
    main()