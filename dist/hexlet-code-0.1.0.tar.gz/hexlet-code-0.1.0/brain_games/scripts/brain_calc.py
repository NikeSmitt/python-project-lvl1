#!/usr/bin/env python3
import brain_games.games.calc_game


def main():
    brain_games.games.calc_game.main()


if __name__ == "__main__":
    main()
