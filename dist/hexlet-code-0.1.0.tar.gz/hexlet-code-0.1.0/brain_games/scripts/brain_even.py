#!/usr/bin/env python3
import brain_games.even_game
import brain_games.scripts.brain_games
import prompt


def main():
    print("Welcome to the Brain Games!")
    name = prompt.string("May I have your name? ")
    print(f"Hello, {name.capitalize()}!")
    brain_games.even_game.main()
    print(f"Congratulations, {name}!")


if __name__ == '__main__':
    main()