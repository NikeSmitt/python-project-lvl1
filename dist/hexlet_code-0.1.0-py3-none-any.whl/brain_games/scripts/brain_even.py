#!/usr/bin/env python3
import brain_games.games.even_game
import brain_games.scripts.brain_games


def main():
    print("Welcome to the Brain Games!")
    brain_games.games.even_game.main()


if __name__ == '__main__':
    main()
