#!/usr/bin/env python3
import brain_games.games.gcd_game


def main():
    print("Welcome to the Brain Games!")
    brain_games.games.gcd_game.main()


if __name__ == "__main__":
    main()
