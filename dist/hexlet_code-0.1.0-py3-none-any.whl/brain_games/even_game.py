import random
import prompt


def is_even(value) -> str:
    return "yes" if value % 2 == 0 else "no"


def main():
    print(f"Answer \"yes\" if the number is even, otherwise answer \"no\".")

    for _ in range(3):
        question_value = random.randint(1, 100)
        print(f"Question: {question_value}")
        answer = prompt.string('Your answer: ')
        if is_even(question_value) == answer:
            print("Correct!")
        else:
            print("Wrong!")


if __name__ == "__main__":
    main()